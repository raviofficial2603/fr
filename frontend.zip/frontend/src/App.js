import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavBar';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from './components/pages/Home';
import Courses from './components/pages/Courses';
import Services from './components/pages/Services';
import Training from './components/pages/Training';
import Footer from './components/Footer';
import AdminHome from './components/adminPages/AdminHome';
// import AddCourse from './components/adminPages/AddCourse';
import EditCourse from './components/adminPages/EditCourse';
import ViewCourse from './components/adminPages/ViewCourse';
import AdminNavBar from './components/adminPages/AdminNavBar';
// import './components/Button.css'



const USER_TYPES={
  PUBLIC:'Public User',
  NORMAL_USER:'Normal User',
  ADMIN_USER:'Admin User'
}
const CURRENT_USER_TYPE=USER_TYPES.ADMIN_USER;
function App() {
  return (
<>
<Router>


<Routes>

<Route path="/admin" exact element={<><AdminNavBar/><AdminHome/></>}/>
<Route path="/courseslist" exact element={<><AdminNavBar/><AdminHome/></>}/>
  
  <Route path="/"   element={<><NavBar/><Home/><Footer/></>} />
  <Route path="/courses"   element={<><NavBar/><Courses/><Footer/></>} />
  <Route path="/services"   element={<><NavBar/><Services/><Footer/></>} />
  <Route path="/training"  element={<><NavBar/><Training/><Footer/></>} />
  


</Routes>

</Router>
  
{/* <Router>
  <NavBar/>
  <Routes>
    <Route path="/home" exact  element={<Home/>} />
    <Route path="/courses"   element={<Courses/>} />
    <Route path="/services"   element={<Services/>} />
    <Route path="/training"  element={<Training/>} />
  </Routes>
<Footer/>
</Router>   */}
  
{/* <AppRouter/> */}



</>
    
    
  );
  function AdminElement(children){
    if(CURRENT_USER_TYPE===USER_TYPES.ADMIN_USER){
      return (
        <>
        
        {children}
        </>
        )
    }
    else{
      return<div>No access.</div>
    }
  }
  function AppRouter(){

  return(<Router>
  <NavBar/>
  <Routes>
    <Route path="/home" exact  element={<Home/>} />
    <Route path="/courses"   element={<Courses/>} />
    <Route path="/services"   element={<Services/>} />
    <Route path="/training"  element={<Training/>} />
    {/* <Route path="/admin" element={
    <AdminElement>
      <AdminHome/>
    </AdminElement>
    }/>

          <Route  path="/addcourse" element={<AdminElement><AddCourse /></AdminElement>} />
          <Route  path="/editcourse/:id" element={<AdminElement><EditCourse /></AdminElement>} />
          <Route  path="/viewcourse/:id" element={<AdminElement><ViewCourse /></AdminElement>} /> */}



  </Routes>
<Footer/>
</Router> ) 
  }
}

export default App;
