import React from 'react'
import MyCarousel from './MyCarousel'


function MainSection() {
  return (
    <div className='main-container'>
        
        
        {/* <img src="/Images/image1.jpg" alt="no where image" /> */}
        <MyCarousel/>
        
      
    </div>
  )
}

export default MainSection
