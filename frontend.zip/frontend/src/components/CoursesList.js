import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import React from 'react'
import CourseItem from './CourseItem'


const courses=[{
    coursename:'C Programming',
    src:'/Images/cprog.png',
    text:'Basic to Advanced',
    label:'C Programming',
    path:'/courses',duration:'60'
},
{   coursename:'C Programming',
    src:'Images/cpp.png',
    text:'Master C++ from beginners level',
    label:'C++',
    path:'/courses',duration:'60'
},
{   coursename:'C Programming',
    src:'Images/java.png',
    text:'Java Programming for Beginners',
    label:'Java',
    path:'/courses',duration:'60'
},
{   coursename:'C Programming',
    src:'Images/python.jpeg',
    text:'Learn Python: The Complete Python Programming Course',
    label:'Python',
    path:'/courses',duration:'60'
},
{ coursename:'C Programming',
  src:'Images/js.jpeg',
  text:'JavaScript from Beginner to Expert',
  label:'Java Script',
  path:'/courses',duration:'60'
},
{coursename:'C Programming',
src:'Images/salesforce.png',
text:'Salesforce Apex Programming Language',
label:'Salesforce',
path:'/courses',duration:'60'
}
,
{coursename:'C Programming',
src:'Images/webdev.png',
text:'Become a Certified HTML, CSS, JavaScript Web Developer',
label:'Web Development',
path:'/courses',duration:'60'
}
,
{coursename:'C Programming',
src:'Images/php.jpeg',
text:'PHP for Beginners - Become a PHP Master - CMS Project',
label:'PHP',
path:'/courses'
,duration:'60'
}
,
{coursename:'Full Stack',
src:'Images/fullstack.png',
text:'The Complete 2020 Fullstack Web Developer Course',
label:'Web Development',
path:'/courses'
,duration:'60'
}


]


const CoursesList = () => {
  return (
    <>
    <h1 style={{marginTop:'35px'}}>Start Your Journey</h1>
    <Container>
    <Row>
        {
            courses.map((course,index)=><Col key={index} md={4}><CourseItem course={course}/></Col>)
        }
      
    </Row>
    </Container>
        </>
  )
}

export default CoursesList




