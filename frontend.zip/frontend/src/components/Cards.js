import React from 'react';
import './Cards.css';
import CardItem from './CardItem';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
// import React from 'react'

function Cards() {
    const courses=[{
        src:'/Images/cprog.png',
        text:'Basic to Advanced',
        label:'C Programming',
        path:'/courses'
    },
    {
        src:'Images/cpp.png',
        text:'Master C++ from beginners level',
        label:'C++',
        path:'/courses'
    },
    {
        src:'Images/java.png',
        text:'Java Programming for Complete Beginners',
        label:'Java',
        path:'/courses'
    },
    {
        src:'Images/python.jpeg',
        text:'Learn Python: The Complete Python Programming Course',
        label:'Python',
        path:'/courses'
    },
    {
      src:'Images/js.jpeg',
      text:'JavaScript from Beginner to Expert',
      label:'Java Script',
      path:'/courses'
  },
  {
    src:'Images/salesforce.png',
    text:'Salesforce Apex Programming Language',
    label:'Salesforce',
    path:'/courses'
}
,
  {
    src:'Images/webdev.png',
    text:'Become a Certified HTML, CSS, JavaScript Web Developer',
    label:'Web Development',
    path:'/courses'
}
,
  {
    src:'Images/php.jpeg',
    text:'PHP for Beginners - Become a PHP Master - CMS Project',
    label:'PHP',
    path:'/courses'
}
,
  {
    src:'Images/fullstack.png',
    text:'The Complete 2020 Fullstack Web Developer Course',
    label:'Web Development',
    path:'/courses'
}
    
    
]
const co1={src:'Images/fullstack.png',
text:'The Complete 2020 Fullstack Web Developer Course',
label:'Web Development',
path:'/courses'}
const structuredCourses=[]
let temp=[];

if(courses.length%2!==0){

  for(let i=0;i<courses.length;i+=3){
    if(i+2<courses.length)
    structuredCourses.push([courses[i+0],courses[i+1],courses[i+2]])
    else
    {
        while(i<courses.length)
            temp.push(courses[i++])
            
            structuredCourses.push(temp)
          }
        }
}
else{
  for(let i=0;i<courses.length;i+=2)
  structuredCourses.push([courses[i+0],courses[i+1]])

}
// structuredCourses=courses


    // structuredCourses.map((courses)=>{
    //     <l className='cards__items'>

    //     {courses.map((course,index)=><CardItem key={index} {...course}/>)}

    //     </l>
    // })
    // < className='cards__items'>
            
const row =    structuredCourses.map((courses)=>{ return(

    <ul className='cards__items'>

{courses.map((course,index)=><CardItem key={index} {...course}/>)}

</ul>
    )

})




  return (
    <div className='cards'>
      <h1>Glance of Courses</h1>
      <div className='cards__container'>
        <div className='cards__wrapper'>
        <Container>
        <Row>

          {/* {row} */}


          
            {courses.map((course,index)=>
            <Col md={4}  key={index}><CardItem {...course}/></Col>
            )}
            
        </Row>
        </Container>



          {/* <ul className='cards__items'>
            <CardItem
              src='Images/js.jpeg'
              text='Set Sail in the Atlantic Ocean visiting Uncharted Waters'
              label='Mystery'
              path='/services'
            />
            <CardItem
              src='images/img-4.jpg'
              text='Experience Football on Top of the Himilayan Mountains'
              label='Adventure'
              path='/products'
            />
            <CardItem
              src='images/img-8.jpg'
              text='Ride through the Sahara Desert on a guided camel tour'
              label='Adrenaline'
              path='/sign-up'
            />
          </ul> */}
        </div>
          
    <Container>
    <Row >
      <Col md={4}><CardItem   {...co1}/></Col>
      <Col md={4}><CardItem {...co1}/></Col>
      <Col md={4}><CardItem {...co1}/></Col>
      <Col md={4}><CardItem {...co1}/></Col>     

      <Col md={4}><CardItem {...co1}/></Col>
      <Col md={4}><CardItem {...co1}/></Col>
      

    </Row>
    </Container>



      </div>
    </div>
  );
}

export default Cards;