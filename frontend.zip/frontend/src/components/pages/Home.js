import React from 'react'
import MainSection from '../MainSection'
import '../../App.css'
import Cards from '../Cards'
import Canvas from './Canvas'
import NavBar from '../NavBar'

const Home = () => {
  return (
    <>
      
     <MainSection/> 
     <Cards/>
    </>
  )
}

export default Home
