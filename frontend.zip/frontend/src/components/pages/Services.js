import React from 'react'
import '../../App.css'
const Services = () => {
    console.log('sercicalf');
  return (
    <div>
        
      <h1 className='services'>Services</h1>;
    </div>
  )
}

export default Services
