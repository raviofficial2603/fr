import React from 'react'
import '../../App.css'
const Training = () => {
  return (
    <div>
      <h1 className='training'>Training</h1>;
    </div>
  )
}

export default Training
