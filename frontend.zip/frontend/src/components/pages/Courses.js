import React from 'react'
import '../../App.css'
import CoursesList from '../CoursesList'
const Courses = () => {
  return (
    <div>
      {/* <h1 className='courses'>Courses</h1>; */}
      <CoursesList/>
    </div>
  )
}

export default Courses
