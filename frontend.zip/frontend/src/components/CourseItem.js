import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import './CourseItem.css'
function CourseItem(props) {
  return (
    <>
    <div className="card mt-5 mb-3 overflow"style={{}}>
        <div className="overflow">

    <img src={props.course.src}  className="card-img-top " style={{maxHeight:'300px'}} alt="..."/>
        </div>
    <div className="card-body">
    <h5 className="card-title">{props.course.label}</h5>
    <h6 className="card-title">Duration: {props.course.duration} days</h6>
    <p className="card-text" style={{textAlign:'justify'}}>{props.course.text}.Some quick example text to build on the card title and make up the bulk of the card.</p>
    <button href="#" className="btn btn-primary">Know More</button>
    </div>
    </div>
    
    </>
  );
}

export default CourseItem;