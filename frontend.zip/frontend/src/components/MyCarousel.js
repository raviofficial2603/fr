import Carousel from 'react-bootstrap/Carousel';
import Btn from './Btn';
import './MyCarousel.css'
import Button from 'react-bootstrap/Button';

function MyCarousel() {
  return (
    <Carousel fade>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100"
          src="/Images/studentg.jpg"
          alt="First slide"
          
        />
        <Carousel.Caption>
        <h3>ENHANCES LEARNING</h3>
        <p>One-Stop solution to level-up your skills.</p>
        <Button className='btn btn-info me-3 mt-2 text-dark btn-lg' >Get Started</Button>
        <Button className="btn btn-info me-3 mt-2 text-dark btn-lg">Sign Up</Button>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100"
          src="/Images/glp.jpg"
          alt="Second slide" 
        />

        <Carousel.Caption >
          <h3 className='text-white'>BEST TUTORS</h3>
          <p className='text-white'>Meet most experienced faculty</p>
          <Button className='btn btn-info me-3 mt-2 text-dark btn-lg' >Get Started</Button>
          <Button className="btn btn-info me-3 mt-2 text-dark btn-lg ">Sign Up</Button>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item interval={3000}>
        <img
          className="d-block w-100"
          src="/Images/facing.jpg"
          alt="Third slide" 
        />

        <Carousel.Caption>
          <h3>ENGAGE YOURSELF</h3>
          <p>
            Experience best teaching methods
          </p>

          {/* <Btn buttonStyle='btn--dark' buttonSize='btn--medium'>Get Started</Btn>
          <Btn buttonStyle='btn--dark' buttonSize='btn--medium'>Sign Up</Btn> */}
          {/* <Button   buttonStyle='btn--outline' buttonSize='btn--medium'>Sign Up</Button> */}
          <Button className='btn btn-info me-3 mt-2 text-dark btn-lg' >Get Started</Button>
          <Button className="btn btn-info me-3 mt-2 text-dark btn-lg">Sign Up</Button>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default MyCarousel;