// import axiom from "axiom";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams ,useLocation} from "react-router-dom";


import AdderModal from './AdderModal'
import DeleteModal from "./DeleteModal";
import EditModal from "./EditModal";
import ViewModal from "./ViewModal";
import CourseService from "./CourseService";
// import { useHistory } from "react-router-dom";
import { useNavigate } from 'react-router-dom';


export default function AdminHome() {
 const navigate=useNavigate();

  const COURSE_API_BASE_URL="http://localhost:8080/courses";
    const intialCourses=[{
        id:'1',
        courseName:'Java',
        mentorName:'Sudharshan',
        
    },
    {   id:'2',
        courseName:'C Programming',
        mentorName:'Sudha Kishore',
        
    },
    {   id:'3',
        courseName:'Python',
        mentorName:'Naga Babu',
        
    }]

  const [courses, setCourses] = useState(intialCourses);

  // const { id } = useParams();
  

  const loadCourses=()=>{
    CourseService.getCourses().then(res=>{
      setCourses(res.data);
      console.log(res.data);
      console.log(courses);
      
      
    });
    setCourses([...courses]);
    
  }


  
//   const location = useLocation();
  useEffect(() => {
    console.log("rendered");
    loadCourses();
  },[]);
//   console.log(location.state)
//   console.log(courses)
  // const loadCourses =  () => {
    // const result = await axios.get("http://localhost:8080/users");
    // setUsers(result.data);
    // console.log(courses)
    // console.log('tell me'+location.state)
    // console.log(courses)
    // if(location.state){
    //     console.log('inside if')
    //     const {id,courseName,mentorName,email}=location.state;
    //     console.log(id,courseName,mentorName,email)
    //     setCourses([...courses,{id:'99',courseName,mentorName,email}]);
    // }
    // console.log(courses);
        
  //  };
//   const addCourse=()=>{
//     location.state?setCourses([...courses,location.state]):console.log('no');
//     location.state=false;
//     console.log(location.state)
//   }
   const addCourse=(course)=>{
        // course.id=courses.length+1

        // setCourses([...courses,course])
        console.log('employee=>'+JSON.stringify(course));
        CourseService.addCourse(course);
        loadCourses();
        // setCourses(...courses);
        

   }
   const editCourse=(Editcourse)=>{

    courses[Editcourse.id-1]=Editcourse
    setCourses([...courses])
   }
  const deleteCourse =  (Deletecourse) => {
    // await axios.delete(`http://localhost:8080/user/${id}`);
    // courses.splice(Deletecourse.id-1)
    let arr = courses.filter((Course) =>Course.id !== Deletecourse.id)
    console.log(arr)
    setCourses([...arr])


    // loadCourses();
  };

//   deleteCourse('hi')
  

  return (



    <div className="container">
        <AdderModal addCourse={addCourse}/>
      <div className="py-4">
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">Sl.No</th>
              <th scope="col">Course Name</th>
              <th scope="col">Mentor Name</th>
              
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((course , index) => (
              <tr>
                <th scope="row" key={index}>
                  {index + 1}
                </th>
                <td>{course.courseName}</td>
                <td>{course.mentorName}</td>
                
                <td>
                  {/* <Link
                    className="btn btn-primary mx-2"
                    to={`/viewcourse/${course.id}`}
                  >
                    View
                  </Link> */}
                  <ViewModal   course={course}/>
                  {/* <Link
                    className="btn btn-outline-primary mx-2"
                    to={`/editcourse/${course.id}`}
                  >
                    Edit
                  </Link> */}
                  <EditModal course={course} editCourse={editCourse}/>
                  {/* <button
                    className="btn btn-danger mx-2"
                    //onClick={() => deleteUser(course.id)}
                  >
                    Delete
                  </button> */}

                  <DeleteModal course={course} delCourse={deleteCourse} />
                

                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}