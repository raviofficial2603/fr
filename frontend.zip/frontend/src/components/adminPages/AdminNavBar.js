import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  console.log('Admin Nav bar');
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Admin Login
          </Link>

        </div>
      </nav>
    </div>
  );
}