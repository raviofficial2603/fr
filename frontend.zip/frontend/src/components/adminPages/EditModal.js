import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import {Link} from 'react-router-dom'

function EditModal(props) {
  const values = [true];
  const [fullscreen, setFullscreen] = useState(true);
  const [show, setShow] = useState(false);
  const [course, setCourse] = useState({...props.course});
  const onInputChange = (e) => {
    setCourse({ ...course, [e.target.name]: e.target.value });
    console.log(course)
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    
    props.editCourse(course)
    console.log(course);
    setShow(false)
  }
    const { coursename, mentorname, email } = course;


  function handleShow(breakpoint) {
    setFullscreen(breakpoint);
    setShow(true);
  }

  return (
    <>
                  
        {values.map((v, idx) => (
        

        <Button key={idx}   variant="outline-primary" onClick={() => handleShow(v)}>
          Edit
          {typeof v === 'string' && `below ${v.split('-')[0]}`}
        </Button>
          
      ))}
        {/* <div className="d-grid gap-2">

        <Button variant="primary" size="lg">
        Block level button
      </Button> 
      </div>
      */
      }
      
      <Modal show={show} fullscreen={fullscreen} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Course</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Enter Course Details</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                Course Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Course name"
                name="coursename"
                value={coursename}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Mentor Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Mentor Name"
                name="mentorname"
                value={mentorname}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
                E-mail
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter mentor e-mail address"
                name="email"
                value={email}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            
            <div className="btn btn-outline-danger mx-2" onClick={()=>setShow(false)}>
              Cancel
            </div>
          </form>
        </div>
      </div>
    </div>

        </Modal.Body>
      </Modal>
    </>
  );
}

export default EditModal;