import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import {Link} from 'react-router-dom'

function AdderModal(props) {
  const values = [true];
  const [fullscreen, setFullscreen] = useState(true);
  const [show, setShow] = useState(false);
  const [course, setCourse] = useState({
    courseName: "",
    mentorName: "",
    
  });
  const onInputChange = (e) => {
    setCourse({ ...course, [e.target.name]: e.target.value });
    console.log(course)
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    props.addCourse(course)
    setCourse({
      courseName: "",
      mentorName: "",
      
    })
    setShow(false)
  }
    const { courseName, mentorName } = course;


  function handleShow(breakpoint) {
    setFullscreen(breakpoint);
    setShow(true);
  }

  return (
    <>
                  
        {values.map((v, idx) => (
        <div class="d-grid gap-2 col-6 mx-auto">

        <Button key={idx}  size='lg'className="mt-3 cl-1 btn b  " variant="outline-success" onClick={() => handleShow(v)}>
          Add Course
          {typeof v === 'string' && `below ${v.split('-')[0]}`}
        </Button>
        </div>  
      ))}
        {/* <div className="d-grid gap-2">

        <Button variant="primary" size="lg">
        Block level button
      </Button> 
      </div>
      */
      }
      
      <Modal show={show} fullscreen={fullscreen} onHide={() => setShow(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Adding Course</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Enter Course Details</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                Course Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Course name"
                name="courseName"
                value={courseName}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                Mentor Name
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Mentor Name"
                name="mentorName"
                value={mentorName}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            
            <div className="btn btn-outline-danger mx-2" onClick={()=>setShow(false)}>
              Cancel
            </div>
          </form>
        </div>
      </div>
    </div>

        </Modal.Body>
      </Modal>
    </>
  );
}

export default AdderModal;