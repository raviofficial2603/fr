import axios from "axios";
const COURSE_API_BASE_URL="http://localhost:8080/courses";
// import React from 'react'

// import React, { Component } from 'react'

export class CourseService  {
  getCourses(){
    return axios.get(COURSE_API_BASE_URL);
  }
  addCourse(course){
    return axios.post(COURSE_API_BASE_URL,course);
  }

}

export default new CourseService()

